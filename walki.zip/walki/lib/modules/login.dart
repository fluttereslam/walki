import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:walki/shared/components/components.dart';
class Log_in extends StatelessWidget {
// const HomeLayout({Key? key}) : super(key: key);
Color start = HexColor("#214E8A").withOpacity(0.99);//.withAlpha(250);//.withOpacity(0.9);
Color end = HexColor("#FD5B1F").withOpacity(0.66);//.withOpacity(0.7);
var namecontroller = TextEditingController();
var passwordcontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        leading: MaterialButton(onPressed: () {  },
        child: Image.asset("assets/images/Vector.png"),),
        elevation: 0,

      ),

      body: Container(
        padding: EdgeInsets.all(20),
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
         //gradient: RadialGradient(colors: colors)
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            //  // tileMode: TileMode.mirror,
            //  // transform: Matrix4.translationValues(x, y, z),
              stops: [

                0.1,1.0,

              ],
              colors: [
              //Colors.blue,

               //Colors.orange,
                start,end,


              ]
          )
        ),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height:  MediaQuery.of(context).size.height/20,),
            Row(
              mainAxisAlignment:MainAxisAlignment.center,
              children: [
              Text("Wa",style: TextStyle(fontFamily:"Poppins",fontSize: 50,fontWeight: FontWeight.w400,color: HexColor("#FFFFFF")),),
              Text("l",style: TextStyle(fontFamily:"Poppins",fontSize: 50,fontWeight: FontWeight.w400,color: HexColor("#FD5B1F")),),
              Text("k",style: TextStyle(fontFamily:"Poppins",fontSize: 50,fontWeight: FontWeight.w400,color: HexColor("#FFFFFF")),),
              Text("i",style: TextStyle(fontFamily:"Poppins",fontSize: 50,fontWeight: FontWeight.w400,color: HexColor("#FD5B1F")),),
              Text("e",style: TextStyle(fontFamily:"Poppins",fontSize: 50,fontWeight: FontWeight.w400,color: HexColor("#FFFFFF")),),

            ],),
            SizedBox(height:  MediaQuery.of(context).size.height/7,),

            defaultFormfield(
               controller: namecontroller,
               type: TextInputType.name,
               validate: (value){},
               label: "username", ),
            SizedBox(height: 24,),
            defaultFormfield(
              controller: passwordcontroller,
              type: TextInputType.name,
              validate: (value){},
              label: "password",
            suffix: Icons.visibility),
            SizedBox(height: 32,),

            defaultButton(function: (){},
                background: HexColor("#214E8A"),
                text: "Sign in",
            ),
            SizedBox(height: 15.0,),

            Row(
              children: [

                Container(
                  padding: EdgeInsets.only(left: 60.0),
                  width: MediaQuery.of(context).size.width/2.6,
                  child: Divider(
                thickness: 2.0,
                    height: 1.0,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 8.0,),
                Text("OR",style: TextStyle(color: Colors.white,fontSize: 14,fontWeight: FontWeight.w400,fontFamily: "Poppins"),),
                SizedBox(width: 8.0,),
                Container(
                  padding: EdgeInsets.only(right: 60.0),
                  width: MediaQuery.of(context).size.width/2.6,
                  child: Divider(
                    thickness: 2.0,
                    height: 1.0,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            SizedBox(height: 26.0,),
            Row(
              children: [
                Container(
                  padding: EdgeInsets.only(left: 60.0),
                  //width: MediaQuery.of(context).size.width/2.6,
                  child:
                  Text(
                    "Log in With",textAlign:TextAlign.left ,style: TextStyle(color: Colors.white,fontSize: 14,fontFamily: "Poppins"),),

                ),
                SizedBox(width: 26.0),
                InkWell(
                  onTap: (){},
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 10,
                      backgroundImage: AssetImage("assets/images/facee.png")),
                ),
                SizedBox(width: 12.0),
                InkWell(
                  onTap: (){},
                  child: CircleAvatar(
                      backgroundColor: Colors.orange,
                      radius: 12,
                      backgroundImage: AssetImage("assets/images/google.png",)),
                ),// Image.asset("assets/images/facebook.png")),

                
              ],),
          ],
         // child: Text("walkie",style:TextStyle(fontSize: 30,fontFamily: "Poppins"),),
        ),
      )



    );
  }
}



