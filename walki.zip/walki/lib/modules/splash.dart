

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hexcolor/hexcolor.dart';

import '../shared/components/components.dart';

class Splash extends StatelessWidget {
  const Splash({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarBrightness: Brightness.light,
        statusBarIconBrightness: Brightness.light,
        statusBarColor: HexColor("#214E8A"),

      ),
      child: Scaffold(
        body: SingleChildScrollView(
          physics: NeverScrollableScrollPhysics(),
          child: Column(
            
            children: [
              Stack(
                alignment: Alignment.center,
               //clipBehavior:Clip.none,

                children: [
                  Container(
                    width: double.infinity,
                   // height: double.infinity,
                    child: Image.asset("assets/images/women.png",fit: BoxFit.fitHeight,),
                  ),
                  Container(
                    width: double.infinity,
                    //height: MediaQuery.of(context).size.height*0.25,
                    //color: Colors.white24,
                    child: CustomPaint(
                      foregroundPainter: Linepainter(),
                    ),
                  ),
                  //
                  // Container(
                  //   width: double.infinity,
                  //  // height: MediaQuery.of(context).size.height*0.49,
                  //   //color: Colors.blue,
                  //   child: CustomPaint(
                  //     foregroundPainter: Linepainter1(),
                  //   ),
                  // ),

                ],
              ),
            ],
          ),
        ),

      ),
    );
  }
}
