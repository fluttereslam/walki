// import 'package:flutter/material.dart';
// import 'package:video_player/video_player.dart';
//
// void main() => runApp(const VideoApp());
//
// /// Stateful widget to fetch and then display video content.
// class VideoApp extends StatefulWidget {
//   const VideoApp({Key? key}) : super(key: key);
//
//   @override
//   _VideoAppState createState() => _VideoAppState();
// }
//
// class _VideoAppState extends State<VideoApp> {
//   late VideoPlayerController _controller;
//
//   @override
//   void initState() {
//     super.initState();
//     _controller = VideoPlayerController.network(
//         'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4')
//       ..initialize().then((_) {
//         // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
//         setState(() {});
//       });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Video Demo',
//       home: Scaffold(
//         body: Center(
//
//           child:Container(
//             height: 200,
//             width: 200,
//             child:    _controller.value.isInitialized
//                 ? AspectRatio(
//               aspectRatio: _controller.value.aspectRatio,
//               child: VideoPlayer(_controller),
//             )
//                 : Container(
//              child: Text("font",style: TextStyle(),
//             ),
//           ),
//
//           ),
//         ),
//
//         floatingActionButton: FloatingActionButton(
//           onPressed: () {
//             setState(() {
//               _controller.value.isPlaying
//                   ? _controller.pause()
//                   : _controller.play();
//             });
//           },
//           child: Icon(
//             _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
//           ),
//         ),
//
//     ));
//   }
//
//   @override
//   void dispose() {
//     super.dispose();
//     _controller.dispose();
//   }
// }

// appBar: AppBar(
//
// actions: [
//   IconButton(onPressed: (){},
//       icon: Container(
//         width: 45.0,
//         height: 25.0,
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(30),
//           color: Colors.deepOrange.withOpacity(0.4),
//         ),
//         child: Icon(
//           Icons.arrow_back_outlined,
//           color: Colors.deepOrange,
//         ),
//       )),
//   IconButton(onPressed: (){},
//       icon: Container(
//         width: 45.0,
//         height: 25.0,
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(30),
//           color: Colors.deepOrange.withOpacity(0.4),
//         ),
//         child: Icon(
//           Icons.menu_outlined,
//           color: Colors.deepOrange,
//         ),
//   )),
//   IconButton(onPressed: (){}, icon: Stack(
//     children: [
//       CircleAvatar(
//         backgroundColor: Colors.white70,
//         radius: 20.0,
//       ),
//       Padding(padding: EdgeInsets.all(1.0),
//         child: CircleAvatar(
//           backgroundColor: Colors.black54,
//           child: Icon(Icons.search,color: Colors.white,),
//         ),)
//     ],
//   )),
//   Spacer(),
//   IconButton(onPressed: (){},
//       icon:Stack(
//         children: [
//           CircleAvatar(
//             backgroundColor: Colors.deepOrange,
//             radius: 20.0,
//           ),
//           Padding(padding: EdgeInsets.all(2.0),
//             child: CircleAvatar(
//               backgroundColor: Colors.black,
//             ),),
//           Padding(padding: EdgeInsets.all(4.0),
//             child: CircleAvatar(
//               backgroundImage: AssetImage("assets/images/facee.png"),
//             ),)
//         ],
//       )
//  ),
//   //Poppins
//
//
// ],
//
// ),