
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
FocusNode myFocusNode =  FocusNode();
Widget defaultFormfield({

  required TextEditingController controller,
  required TextInputType type,
  ValueChanged? onSubmit,
  ValueChanged? onchange,
  GestureTapCallback?onTap,
  required FormFieldValidator? validate,
  required  String label,
  IconData? prefix,
  IconData? suffix,
  bool isPassword = false,
  Color textColor = Colors.white,
  GestureTapCallback? SuffixPressed,
}) =>TextFormField(
  style: TextStyle(color:textColor ),
  controller: controller,
  keyboardType: type,
  onFieldSubmitted: onSubmit,
  onChanged: onchange,
  validator: validate,
  obscureText: isPassword,
  cursorColor: HexColor("#FFFFFF"),
  decoration: InputDecoration(
contentPadding: EdgeInsets.all(2),


    labelText: label,
    labelStyle: TextStyle(
        color: myFocusNode.hasFocus ? HexColor("#FFFFFF") :HexColor("#FFFFFF")),
    prefixIcon: Icon(prefix),
    suffixIcon: IconButton(
        onPressed: SuffixPressed,
        icon: Icon(suffix,color: HexColor("#FFFFFF"),)
    ),
   //fillColor:HexColor("#FFFFFF") ,
   //
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30.0),
      borderSide: BorderSide(
        color: HexColor("#FFFFFF"),
      ),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30.0),
      borderSide: BorderSide(
        color: HexColor("#FFFFFF"),
        width: 1.0,
      ),
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
      



    ),
  ),

  onTap: onTap,
);



Widget defaultButton({
  double width = double.infinity,
  bool IsUpperCase = false,
  Color background = Colors.blueAccent,
  required VoidCallback function,
  required String text,

}) => Container(
  height: 40.0,
  width: width,

  decoration: BoxDecoration(
    color: background,
    borderRadius: BorderRadius.circular(30),
  ),
  child: TextButton(
    onPressed: function,
    child: Text(
      IsUpperCase ? text.toUpperCase() : text,
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w400,
        fontFamily: "Poppins",
        color: Colors.white,
      ),
    ),
  ),
);

class Linepainter extends CustomPainter{

  Radius radiusph  = Radius.circular(350);
  double width =450;
  @override
  void paint(Canvas canvas, Size size){
    final paint = Paint()
      ..strokeWidth=1
      ..color=Colors.white
    ..style = PaintingStyle.stroke;
    final arc1 =Path();
    arc1.moveTo(size.width*0.0, size.height*0.3);
    arc1.arcToPoint(
        Offset(size.width*1, size.height*0.3),
    radius: Radius.circular(350));

    canvas.drawPath(arc1, paint);
    // to drow line
    // canvas.drawLine(
    //     Offset(size.width*1/6, size.height*1/2),
    //     Offset(size.width*5/6, size.height*1/2),
    //      paint);
  }
  @override
  bool shouldRepaint(CustomPainter olddDelegate)=>false;
}
class Linepainter1 extends CustomPainter{
  @override
  void paint(Canvas canvas, Size size){
    final paint = Paint()
      ..strokeWidth=1
      ..color=Colors.white
    ..style = PaintingStyle.stroke;
    final arc1 =Path();
    arc1.moveTo(size.width*0.0, size.height*0.6);
    arc1.arcToPoint(
        Offset(size.width*1, size.height*0.6),
    radius: Radius.circular(350));

    canvas.drawPath(arc1, paint);
    // to drow line
    // canvas.drawLine(
    //     Offset(size.width*1/6, size.height*1/2),
    //     Offset(size.width*5/6, size.height*1/2),
    //      paint);
  }
  @override
  bool shouldRepaint(CustomPainter olddDelegate)=>false;
}

