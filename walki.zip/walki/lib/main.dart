import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:responsive_framework/responsive_wrapper.dart';
import 'package:responsive_framework/utils/scroll_behavior.dart';

import 'modules/animationtry.dart';
import 'modules/login.dart';
import 'modules/sighnup.dart';
import 'modules/splash.dart';

void main() {

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        builder: (context, child) => ResponsiveWrapper.builder(
            ClampingScrollWrapper.builder(context, child!),
            //  BouncingScrollWrapper.builder(context, child!),
            maxWidth: 1200,
            minWidth: 350,
            defaultScale: true,
            breakpoints: [
              const ResponsiveBreakpoint.resize(350, name: MOBILE),
              const ResponsiveBreakpoint.autoScale(800, name: TABLET),
              const ResponsiveBreakpoint.autoScale(1000, name: TABLET),
              const ResponsiveBreakpoint.resize(1200, name: DESKTOP),
              const ResponsiveBreakpoint.autoScale(2460, name: "4K"),

              //const ResponsiveBreakpoint.autoScale(2460, name: "4K"),
            ],
            breakpointsLandscape: [
              const ResponsiveBreakpoint.resize(560, name: MOBILE),
              const ResponsiveBreakpoint.autoScale(812, name: MOBILE),
              const ResponsiveBreakpoint.resize(1024, name: TABLET),
              const ResponsiveBreakpoint.autoScale(1120, name: TABLET),
            ]
        ),
      theme: ThemeData(
        appBarTheme:
        AppBarTheme(

        backwardsCompatibility:false,
        titleTextStyle: TextStyle(
        color: Colors.black,
        fontSize: 20.0
    ),

    systemOverlayStyle: SystemUiOverlayStyle(
    statusBarColor: HexColor("#214E8A").withOpacity(0.99),
    statusBarBrightness: Brightness.light,
    statusBarIconBrightness: Brightness.light,

    ),
    elevation: 0,
    backgroundColor: HexColor("#214E8A").withOpacity(0.99),
    iconTheme: IconThemeData(
      color: Colors.white
    )

    ),

       // primarySwatch: Colors.,
      ),
      home: Splash(),
    );
  }
}
